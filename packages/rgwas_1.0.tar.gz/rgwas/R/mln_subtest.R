mln_subtest	<- function( X, g, z ){

	g	<- scale(g)

	if( any( is.na( z ) ) ){
		K			<- length(unique(z))-2
	} else {
		K			<- length(unique(z))-1
	}

	#z	<- as.factor(z)

	suppressMessages( out		<- nnet::multinom( z ~ -1+X+g, Hess=T ) )
	
	# contrast matrix
	Tmat	<- cbind( rep(1,K-1), -diag(K-1) )

	# beta contrast vector
	betas			<- as.numeric( summary(out)$coefficients		[,ncol(X)+1] )
	betas.se	<- as.numeric( summary(out)$standard.errors	[,ncol(X)+1] )
	Tbeta			<- Tmat %*% betas
	
	# beta hessian
	g_inds	<- (ncol(X)+1)*(1:K)
	hess_beta	<- out$Hessian[g_inds,g_inds]

	# beta contrast hessian
	I_Tbeta	<- Tmat %*% solve(hess_beta) %*% t(Tmat)

	chi2	<- t(Tbeta) %*% solve( I_Tbeta ) %*% Tbeta

	return( list( betas=betas, betas.se=betas.se, log10p=-pchisq( chi2, K-1, lower.tail=F, log.p=T ) / log(10) ) )

}
