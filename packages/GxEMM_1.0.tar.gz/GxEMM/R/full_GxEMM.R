full_GxEMM	<- function(y, X, K, Z, binary, ldak_loc, mode='REML', ... ){

	if( mode == 'REML' ){
		GxEloc	<- GxEMM
	} else if( mode == 'HE' ){
		GxEloc	<- GxEMM_HE
	}

	time_hom      <- system.time( out_hom       <- GxEloc( y, X, K, Z, binary=binary, ldak_loc=ldak_loc, gtype='hom'									, ... ) )[3]


	#discZ		<- all(Z %in% 0:1) & all(rowSums(Z)==1) #### sklightly better: all( svd( cbind( 1, Z^2 ) )$d > 1e-5 ) #if( length(unique(Z[,1])) == 2 )
	#noise_K0<- ( binary | !discZ )
	#if( discZ & etype=='iid' ){
	#	warning( 'IID etype not identified for discrete Z; running with etype=hom' )
	#time_hom_iid  <- NA
	# out_hom_iid   <- out_iid
	#} else {
	time_hom_iid  <- system.time( out_hom_iid   <- GxEloc( y, X, K, Z, binary=binary, ldak_loc=ldak_loc, gtype='hom'  , etype='iid' 	, ... ) )[3]
	#}



	time_hom_free <- system.time( out_hom_free  <- GxEloc( y, X, K, Z, binary=binary, ldak_loc=ldak_loc, gtype='hom'  , etype='free'	, ... ) )[3]
	time_iid      <- system.time( out_iid       <- GxEloc( y, X, K, Z, binary=binary, ldak_loc=ldak_loc, gtype='iid'  , etype='iid'	, ... ) )[3]
	time_free     <- system.time( out_free      <- GxEloc( y, X, K, Z, binary=binary, ldak_loc=ldak_loc, gtype='free' , etype='free'	, ... ) )[3]

	runtimes	<- list( hom=time_hom	, hom_iid=time_hom_iid, hom_free=time_hom_free, iid=time_iid, free=time_free )
	fits			<- list( hom=out_hom	, hom_iid=out_hom_iid , hom_free=out_hom_free	, iid=out_iid , free=out_free  )

	list( 
		runtimes=runtimes,
		fits=fits,
		pvals=test_gxemm( out_hom, out_iid, out_hom_iid,  out_free, out_hom_free )
	)

}
