sig2map	<- function( sig2s, gtype, etype, K0, noise_K0, discZ, ws ){

	if( gtype == 'hom' & etype == 'hom' ){
		sig2g	<- sig2s[1]
		sig2e	<- sig2s[2]
		h2		<- sig2g/(sig2g+sig2e)
		form	<- list( as.formula("~(x1)/(x1+x2)"))

		names(h2)		<- 'hom'
		names(sig2g)<- 'hom'
		names(sig2e)<- 'hom'

	} else if( gtype == 'iid' & etype == 'hom' ){
		sig2g	<- sig2s[1:2]
		sig2e	<- sig2s[3]
		h2		<- sig2g/(sum(sig2g)+sig2e)
		form	<- lapply( 1:2, function(k) as.formula( paste0( '~x', k, '/(x1+x2+x3)' ) ) )

		names(h2)		<- c( 'hom', 'het' )
		names(sig2g)<- c( 'hom', 'het' )
		names(sig2e)<- 'hom'

	} else if( gtype == 'hom' & etype == 'iid' ){
		sig2g	<- sig2s[1]
		sig2e	<- sig2s[2:3]
		h2		<- sig2g/(sum(sig2g)+sum(sig2e))
		form	<- list( as.formula( '~x1/(x1+x2+x3)' ) )

		names(h2)		<- c( 'hom' )
		names(sig2g)<- c( 'hom' )
		names(sig2e)<- c( 'het', 'hom' )


	} else if( gtype == 'iid' & etype == 'iid' ){
		sig2g	<- sig2s[1:2]
		sig2e	<- sig2s[3:4]
		h2		<- sig2g/(sum(sig2g)+sum(sig2e))
		form	<- list(
			as.formula( '~x1/(x1+x2+x3+x4)' ),
			as.formula( '~x2/(x1+x2+x3+x4)' )
		)

		names(h2)		<- c( 'hom', 'het' )
		names(sig2g)<- c( 'hom', 'het' )
		names(sig2e)<- c( 'het', 'hom' )

	} else if( gtype == 'hom' & etype == 'free' ){
		sig2g		<- sig2s[1]
		if( noise_K0 ){
			if( discZ ){
				sig2e	<- c( sig2s[1+1:K0]+sig2s[2+K0], 0 )
			} else {
				sig2e	<- sig2s[1+1:(K0+1)]
			}
			form	<- lapply( 1:K0, function(k) as.formula( paste0( '~x1/(x1+x',1+k,'+x',K0+2,')' ) ) )
		} else {
			sig2e	<- c(sig2s[1+1:(K0-1)]+sig2s[1+K0],sig2s[1+K0],0)
			form	<- lapply( 1:K0, function(k) as.formula( paste0( '~x1/(x1+x',ifelse( k!=K0, paste0(1+k,'+x'), '' ),K0+1,')') ) )
		}
		h2		<- sig2g/(sig2g+sig2e[1:K0]+sig2e[K0+1])

		names(h2)		<- paste0( 'h2_', 1:K0 )
		names(sig2g)<- 'hom'
		names(sig2e)<- c( paste0( 'sig2e_', 1:K0 ), 'hom' )

	} else if( gtype == 'free' & etype == 'free' ){
		sig2g		<- sig2s[1:(K0+1)]
		if( noise_K0 ){
			if( discZ ){
				sig2e	<- c( sig2s[K0+1+1:K0]+sig2s[2*K0+2], 0 )
			} else {
				sig2e	<- sig2s[K0+1+1:(K0+1)]
			}
			form	<- lapply( 1:K0, function(k) as.formula( paste0( '~(x1+x',1+k,')/(x1+x',1+k,'+x',1+K0+k,'+x',2*K0+2,')') ) )
		} else {
			sig2e	<- c(sig2s[K0+1+1:(K0-1)]+sig2s[2*K0+1],sig2s[2*K0+1],0)
			form	<- lapply( 1:K0, function(k) as.formula( paste0( '~(x1+x',1+k,')/(x1+x',1+k,'+x',ifelse(k!=K0,paste0(1+K0+k,'+x'),''),2*K0+1,')') ) )
		}
		h2		<- (sig2g[1] + sig2g[-1])/(sig2g[1] + sig2g[-1]+sig2e[1:K0]+sig2e[K0+1])

		names(h2)		<- paste0( 'h2_', 1:K0 )
		names(sig2g)<- c( 'hom', paste0( 'sig2g_', 1:K0 ) )
		names(sig2e)<- c( paste0( 'sig2e_', 1:K0 ), 'hom' )

	} else if( gtype == 'free' & etype == 'hom' ){
		sig2g	<- sig2s[1:(K0+1)]
		sig2e	<- sig2s[1+K0+1]
		form	<- lapply( 1:K0, function(k) as.formula(paste0( '~(x1+x', 1+k, ')/(x1+x', 1+k, '+x', 1+K0+1, ')')) )
		h2		<- (sig2g[1] + sig2g[-1])/(sig2g[1] + sig2g[-1]+sig2e)

		names(h2)		<- paste0( 'h2_', 1:K0 )
		names(sig2g)<- c( 'hom', paste0( 'sig2g_', 1:K0 ) )
		names(sig2e)<- 'hom'

	} else {
		stop(c(gtype,etype))
	}

	H2	<- sig2g * ws[ 1:length(sig2g) ]

	list( sig2g=sig2g, sig2e=sig2e, form=form, h2=h2, H2=H2	)
}
