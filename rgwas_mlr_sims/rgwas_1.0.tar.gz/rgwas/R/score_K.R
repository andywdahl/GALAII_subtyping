score_K<- function( Yb, Yq, G, X=NULL, K, n.folds=10, z_baseline, scaling=T, seed=12345, ... ){

	B		<- ncol(Yb)
	P		<- ncol(Yq)
	N		<- nrow(Yq)
	set.seed( seed )
	subs<- split( 1:N, sample( rep(1:n.folds,N), N ) )

	if( scaling ){
		Yq	<- scale(Yq)
		#G		<- scale(G)
		#if( !is.null(X) )
		#X		<- scale(X)
	}

	score_matrix	<- matrix( NA, n.folds, 3 )
	colnames(score_matrix)	<- c( 'oos_ll', 'entropy', 'consistency_w_baseline' )
	for( kk in 1:n.folds ){
		cat( '\nrunning fold ', kk, '....\n' )
		sub			<- subs[[kk]]
		
		trn_Yb	<- Yb[-sub,,drop=F]
		trn_Yq	<- Yq[-sub,,drop=F]
		trn_G 	<- G [-sub,,drop=F]

		tst_Yb	<- Yb[sub,,drop=F]
		tst_Yq	<- Yq[sub,,drop=F]
		tst_G 	<- G [sub,,drop=F]
		Ntest		<- nrow(tst_Yq)


		if( !is.null(X) ){
			trn_X 	<- X [-sub,,drop=F]
			tst_X 	<- X [sub,,drop=F]
		} else {
			trn_X 	<- NULL
			tst_X 	<- NULL
		}

		if( K > 1 ){
			allout	<- mfmr( trn_Yb, trn_Yq, trn_G, trn_X, K, ... )
			out	<- allout$out
			if( !is.null(X) ){
				Xalpha	<- tst_X %*% out$alpha
			} else {
				Xalpha 	<- matrix( 0, Ntest, P+B )
			}
			score_matrix[kk,1]	<- ll_fxn(		tst_Yb, tst_Yq, Xalpha, tst_G, out$beta	, out$Sigma, out$pvec	, Ntest, P+B, K, B )
			score_matrix[kk,2]	<- -sum( out$pvec*log(out$pvec) )

			if( !missing(z_baseline) ){

				all_perms		<- combinat::permn(K)
				perm_scores	<- rep(NA,length(all_perms))

				#print( names(out) )
				z_base_trn<- z_baseline[-sub]
				pmat_tst 	<- fit_z( tst_Yb, tst_Yq, tst_G, tst_X, out )

				perm_scores	<- sapply( all_perms, function(permi){
					pmat_loc	<- allout$pmat[,permi]
					pmat_loc1	<- pmat_tst   [,permi]
					#print( c( 
					#	mean( apply( pmat_loc, 1, which.max ) == z_base_trn ),
					#	mean( apply( pmat_loc1, 1, which.max ) == z_base_trn )
					#))
					mean( apply( pmat_loc, 1, which.max ) == z_base_trn )
				})

				#print( 'perm scores:' )
				#print( perm_scores )

				bestperm	<- all_perms[[which.max(perm_scores)]]
				z_tst			<- apply( pmat_tst[,bestperm], 1, which.max )

				score_matrix[kk,3]	<- mean( z_tst == z_baseline[sub] )

			}

		} else {
			out	<- mfmr_em_alg_hom( trn_Yb, trn_Yq					, X=cbind( trn_G, trn_X ), ... )
			score_matrix[kk,1]	<- ll_fxn_hom(tst_Yb, tst_Yq, Xalpha=cbind( tst_G, tst_X ) %*% out$alpha, out$Sigma, Ntest, P+B, B )
		}
	}
	cat( 'Done!' )
	score_matrix
}
