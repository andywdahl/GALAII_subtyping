droptest	<- function(
	Yb, Yq, G, X=NULL, test_inds, K,
	mc.cores=1,
	mfmrx=FALSE, pmat=NULL,
	...
){

	B	<- ncol(Yb)
	if( !is.null( Yb ) )
		if( is.null( colnames(Yb) ) )
			colnames(Yb)<- paste0( 'Yb'	, 1:ncol(Yb))
	if( !is.null( Yq ) )
		if( is.null( colnames(Yq) ) )
			colnames(Yq)<- paste0( 'Yq'	, 1:ncol(Yq))
	if( is.null( colnames(G) ) )
		colnames(G)		<- paste0( 'G'	, 1:ncol(G) )
	phens	<- c( colnames( Yb ), colnames( Yq ) )
	P			<- length(phens)

	##### set up fixed out
	if( mfmrx & is.null(pmat) ){
		mfmr_time	<- system.time({
			pmat	<- mfmr( Yb, Yq, G, X, K, mc.cores=mc.cores, ... )$pmat
		})[3]
		cat( 'mfmr time:', round( mfmr_time/60, 1 ), 'min.', '\n' )
	}

	##### test each column of G
	gxe_outs	<- parallel::mclapply( 1:ncol(G), mc.cores=mc.cores, function(test_ind){
		if( ! test_ind %in% test_inds ) return(NA)
		cat( 'Running G index ', test_ind, '\n' )

		##### fit mfmr
		mc.cores.mfmr	<- ifelse( mc.cores <= length( test_inds ), 1, floor(mc.cores/length(test_inds)) )
		if( ! mfmrx  ){
			mfmr_time	<- system.time({
				pmat	<- mfmr( Yb, Yq, G[,-test_ind,drop=F], cbind( X, G[,test_ind] ), K, mc.cores=mc.cores.mfmr, ... )$pmat
			})[3]
			cat( 'mfmr time:', round( mfmr_time/60, 1 ), 'min.', '\n' )
		}

		##### test
		Gxpmat	<- t(sapply( 1:nrow(G), function(i) G[i,-test_ind,drop=F] %x% pmat[i,] ))

		test_time	<- system.time({
			out	<- lapply( 1:P, function(pp){
				bin	<- (pp <= B )
				y		<- cbind( Yb, Yq )[,pp]
				out1	<- interxn_test( X=cbind( X, pmat[,-K,drop=F], Gxpmat ), y=y, g=G[,test_ind], pmat=pmat[,-K,drop=F], bin=bin )
				#print( names( out1 ) )
				#print( names( out1$pvals ) )
				list( pvals=out1$pvals, summ=out1$coef )
			})
		})[3]
		rm( Gxpmat )
		cat( 'test time:', round( test_time/60, 1 ), 'min.', '\n' )
		#print( 'gggggg' )
		#print( rownames( (out[[1]])$coef ) )
		#print( 'gggggg' )
		out
	})
	#print( 'cc' )

	betas	<- array( NA, dim=c(K,ncol(G),P), dimnames=list( 1:K											, colnames(G), phens ) )
	ses		<- array( NA, dim=c(K,ncol(G),P), dimnames=list( 1:K											, colnames(G), phens ) )
	pvals	<- array( NA, dim=c(3,ncol(G),P), dimnames=list( c( 'Hom', 'Het', 'Glob' ), colnames(G), phens ) )
	for( s in test_inds )
		for( p in 1:P )
	try({

#print( gxe_outs )
#print( gxe_outs[[s]] )
		out_sp	<- gxe_outs[[s]][[p]]
#print( c( s, p ) )
#print( 'xxxxxxxxxxxxx' )
#print( out_sp )
#print( 'yyyyyyyyyyyyy' )
#print( out_sp$summ )
#print( rownames( out_sp$summ ) )
#print( paste0('gxe',1:K) )

		betas	[,s,p]	<- out_sp$summ[paste0('gxe',1:K),'Estimate']
		ses		[,s,p]	<- out_sp$summ[paste0('gxe',1:K),'Std. Error']
		pvals	[,s,p]	<- out_sp$pvals
	})
	#print( 'cc' )
	return(list( betas=betas, ses=ses, pvals=pvals ))
}
