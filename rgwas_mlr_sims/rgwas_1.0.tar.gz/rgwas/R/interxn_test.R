interxn_test	<- function( X, y, g, pmat, bin=FALSE ){
	family	<- ifelse( bin, 'binomial', 'gaussian' )

	gxe			<- apply( pmat, 2, function(x) x*g )

	nullfit	<- glm( y ~ X						, family=family )
	gfit		<- glm( y ~ X + g				, family=family )
	gxefit	<- glm( y ~ X + g + gxe	, family=family )
	pvals	<- c(
		anova( nullfit, gfit	, test='Chisq')$Pr[2],
		anova( gfit		, gxefit, test='Chisq')$Pr[2],
		anova( nullfit, gxefit, test='Chisq')$Pr[2]
	)
	names(pvals)	<- c( 'Hom', 'Het', 'Global' )

	gxe	<- cbind( gxe, (1-rowSums(pmat))*g )
	fit	<- glm( y ~ X + gxe, family=family )

	#return(list( pvals=pvals, fit=fit, pvec=colMeans( pmat, na.rm=T ) ))
	return(list( pvals=pvals, coef=summary(fit)$coef, pvec=colMeans( pmat, na.rm=T ) ))
}

interxn_test_mlr	<- function( X, z, g, ... )
	run_mlr( X=X, g=g, z=z, ... )

run_mlr	<- function( X, g, z, tolfac=1e-4, MaxNWts=1e5, scaleXg=TRUE ){

	if( any( is.na( z ) ) ){
		K			<- length(unique(z))-2
	} else {
		K			<- length(unique(z))-1
	}

	count_tab	<- as.numeric( table( z, exclude=NULL ) )
	#cat( 'Found ', count_tab[1], ' controls; and case subtypes have sizes: ', count_tab[-1], '\n' )

	if( ! all( X[,1] == 1 ) ) stop( 'The first column of X should be an intercept, or a vector of all 1s' )
	if( scaleXg ){
		X	<- cbind( 1, apply( X[,-1], 2, scale01 ) )
		g	<- scale01(g)
	}

	suppressMessages( out		<- nnet::multinom( z ~ -1+X+g, Hess=T, maxit=1e3, abstol = 1.0e-4*tolfac, reltol = 1.0e-8*tolfac, MaxNWts=MaxNWts  ) )

	betas			<- as.numeric( summary(out)$coefficients		[,ncol(X)+1] )
	betas.se	<- as.numeric( summary(out)$standard.errors	[,ncol(X)+1] )

	g_inds		<- (ncol(X)+1)*(1:K)
	tryCatch({
	var_beta	<- solve(out$Hessian)[g_inds,g_inds]
	}, error=function(e){
		print( 'Bad Hessian. Eigenvalues:' )
		print( mean( g ) )
		print( eigen( out$Hessian )$val )
		print( round( (eigen( out$Hessian )$vec)[,ncol(out$Hessian) - 3 + 1:3], 4 ) )
		stop( 'Bad Hessian' )
	})
	rm( out )

	# contrast matrix
	T_hom	<- rep(1,K)
	T_het	<- cbind( rep(1,K-1), -diag(K-1) )
	T_glob<- diag(K)

	# beta contrast vector
	Tbeta_hom	<- T_hom %*% betas
	Tbeta_het	<- T_het %*% betas
	Tbeta_glob<- T_glob%*% betas

	# beta contrast hessian
	I_Tbeta_hom	<- T_hom %*%(var_beta %*% T_hom)
	I_Tbeta_het	<- T_het %*% var_beta %*% t(T_het)
	I_Tbeta_glob<- T_glob%*% var_beta %*% t(T_glob)

	chi2_hom	<- Tbeta_hom^2 / I_Tbeta_hom
	chi2_het	<- t(Tbeta_het) %*% solve( I_Tbeta_het ) %*% Tbeta_het
	chi2_glob	<- t(Tbeta_glob)%*% solve( I_Tbeta_glob) %*% Tbeta_glob

	#### hess_beta	<- out$Hessian[g_inds,g_inds]
	#### I_Tbeta_hom	<- T_hom %*%(solve(hess_beta) %*%   T_hom)
	#### I_Tbeta_het	<- T_het %*% solve(hess_beta) %*% t(T_het)
	#### I_Tbeta_glob<- T_glob%*% solve(hess_beta) %*% t(T_glob)

	return( list( betas=betas, betas.se=betas.se, var_beta=var_beta,
		log10p_hom =as.numeric( -pchisq( chi2_hom	,   1	, lower.tail=F, log.p=T ) / log(10) ),
		log10p_het =as.numeric( -pchisq( chi2_het	, K-1	, lower.tail=F, log.p=T ) / log(10) ),
		log10p_glob=as.numeric( -pchisq( chi2_glob, K		, lower.tail=F, log.p=T ) / log(10) )
	))
}
