droptest_mlr	<- function(
	cc, Yb, Yq, G, X=NULL, test_inds, K,
	mc.cores=1,
	mfmrx=FALSE, pmat=NULL,
	tau=.8,
	#tolfac=1e-4, MaxNWts=1e5, scaleXg=TRUE,
	...
){

	if( 2*length(test_inds) > mc.cores ){
		mc.cores1	<- mc.cores
		mc.cores2	<- 1
	} else {
		mc.cores1	<- length(test_inds)
		mc.cores2	<- floor( mc.cores / mc.cores1 )
	}

	cases	<- which( cc == 1 )
	Yb	<- Yb[cases,,drop=F]
	Yq	<- scale(Yq[cases,,drop=F])

	##### set up fixed out
	if( mfmrx & is.null(pmat) ){
		mfmr_time	<- system.time({
			pmat	<- mfmr( Yb, Yq, G[cases,,drop=F], X[cases,,drop=F], K, mc.cores=mc.cores, ... )$pmat ### todo: what if X is null?
		})[3]
		cat( 'mfmr time:', round( mfmr_time/60, 1 ), 'min.', '\n' )
	}

	out	<- parallel::mclapply( 1:ncol(G), mc.cores=mc.cores1, function(test_ind){
		if( ! test_ind %in% test_inds ) return( list() )
		cat( 'Running G index ', test_ind, '\n' )

		g	<- G[, test_ind,drop=F]
		G	<- G[,-test_ind,drop=F]

		if( is.null(pmat) ){
			cat( 'hetreg_time:', hetreg_time	<- system.time({
				all_out	<- mfmr(Yb, Yq, G[cases,,drop=F], cbind( X, g )[cases,,drop=F], K, mc.cores=mc.cores2, ... )
			})[3], '\n' )
			pmat	<- fit_z(		Yb, Yq, G[cases,,drop=F], cbind( X, g )[cases,,drop=F], all_out$out )
			#cat( 'hetreg_time:', hetreg_time	<- system.time({
			#	pmat	<- mfmr( Yb, Yq, G[cases,,drop=F], cbind( X, g )[cases,,drop=F], K, mc.cores=mc.cores2, ... )$pmat
			#})[3], '\n' )
		}
		Z					<- rep( '0', length(cc) )
		Z[cases]	<- as.character(apply( pmat, 1, function(x) ifelse( max(x) > tau, which.max(x), NA ) ))

		#### todo: add ordinary droptest here
		#run_mlr( cbind( G, X ), g, Z, tolfac=tolfac, MaxNWts=MaxNWts, scaleXg=scaleXg )
		run_mlr( cbind( G, X ), g, Z )
	})
	names(out)	<- colnames(G)

	#betas	<- array( NA, dim=c(K,ncol(G)), dimnames=list( 1:K											, colnames(G) ) )
	#ses		<- array( NA, dim=c(K,ncol(G)), dimnames=list( 1:K											, colnames(G) ) )
	#pvals	<- array( NA, dim=c(3,ncol(G)), dimnames=list( c( 'Hom', 'Het', 'Glob' ), colnames(G) ) )
	#for( s in test_inds )
	#try({
	#	out_s				<- out[[s]]
	#	betas	[,s]	<- out_s$betas
	#	ses		[,s]	<- out_s$betas.se
	#	pvals	[,s]	<- 10^-c( out_s$log10p_hom, out_s$log10p_het, out_s$log10p_glob )
	#})
	#return(list( betas=betas, ses=ses, pvals=pvals ))

	out
}

scale01	<- function(x){
	x	<- x - min(x,na.rm=T)
	x	<- x / max(x,na.rm=T)
	x
}
